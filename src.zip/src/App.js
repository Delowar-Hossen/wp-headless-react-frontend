//import logo from './logo.svg';
import './App.css';
import Pages from './components/Pages/pages';



function App() {
  return (
      <>
        <Pages />
      </>

  );
}

export default App;
