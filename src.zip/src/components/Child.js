import React from 'react';

const Child = () => {

	return <h1>Child</h1>
}
export default Child;