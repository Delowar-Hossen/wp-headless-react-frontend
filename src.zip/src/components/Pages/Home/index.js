import React from 'react'

function Home() {
	return (
		<div>
			<h1 className="text-xl font-bold">Home</h1>
		</div>
	)
}

export default Home