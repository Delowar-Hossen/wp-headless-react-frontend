import React from 'react'
import { Routes, Route  } from 'react-router-dom';
import Home from './Home';
import Posts from './Post';
import Single from './Single';
import Navbar from '../common/Navbar';

function Pages() {
	return (
		<>
			<Navbar />
	      	<Routes>
	        	<Route path="/" element={<Home />} />
	        	<Route path="/posts" element={<Posts />} />
	        	<Route path="/posts/:id" element={<Single />} />
	      	</Routes>
		</>
	)
}

export default Pages